
hgd4 October 2013
=================

used first on T219
------------------
contact: Paul Whittingham

should be quickly reversionable to have different table structure
and cope with differing numbers of textareas without modification to
the code

does not save to local storeage

to reversion:
	- change html in index.html
	
to deploy:
	- see sample stub Structured Content document
	- note that the second and third instances have a "parent_activity_id" parameter, which
	  points to the id of the first one
	- doesn't have to be three instances: could be one or any number within the same document


