var pinboard_data = {
    "id":"k238_u6_i20",
    "activity_width":    880,
    "activity_height":   605,
    "pinboard_width" :   710,
    "pinboard_height":   595,
    "stickynote_height": 100,
    "stickynote_width":  100,
    "fileMenu":false,
    "note_colours":["#FFF7C6","#A2D7DB","#F8C7DC","#B8DAB7"],
    "img":{
        "pinboardBg":"graphics/perspectives_bg.png"},
    "preloaded_notes": [{"text":"Surgical team","bgColour":"rgb(255, 247, 198)","x":147,"y":319,"zIndex":"4"}]
};
